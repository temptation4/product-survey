package com.product.Product.survey.controller;

import com.product.Product.survey.exception.ResourceNotFoundException;
import com.product.Product.survey.model.Product;
import com.product.Product.survey.model.Product_viewer;
import com.product.Product.survey.repository.ProductRepository;
import com.product.Product.survey.repository.WorkerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.*;

import static javax.print.attribute.standard.ReferenceUriSchemesSupported.HTTP;

@RestController
public class ProductController {

    @Autowired
    ProductRepository productRepository;

    @Autowired
    WorkerRepository workerRepository;

    //LIST of products by barcode
    @RequestMapping("/products/{barcodeId}")
    public List<Product> getAllProductsByBarcode(@PathVariable(value = "productId") String barcode
                                                 ) {
        return productRepository.findByBarcode(barcode);
    }


    //product is selected from the list
    @RequestMapping("/products/{workerId}/product")
    public Product_viewer addProductinList(@PathVariable(value = "workerId") Long workerId
                                                 ) {
        List<Product> products = productRepository.findByWorkerId(workerId);
        ArrayList<Product> list=new ArrayList<>();
        Product product=new Product();
       for(int i=0;i<=products.size();i++) {
           product.setBarcode(products.get(i).getBarcode());
           product.setDescription(products.get(i).getDescription());
           product.setPrice(products.get(i).getPrice());

           list.add(product);
       }

        OptionalDouble lowerPrice = products
                .stream()
                .mapToDouble(p->p.getPrice())
                .min();

        OptionalDouble maximumPrice = products
                .stream()
                .mapToDouble(p->p.getPrice())
                .max();
        OptionalDouble average = products
                .stream()
                .mapToDouble(p->p.getPrice())
                .average();

        Product_viewer product_viewer=new Product_viewer();
        product_viewer.setBarcode(product.getBarcode());
        product_viewer.setLowest_price(lowerPrice.getAsDouble());
        product_viewer.setHighest_price(maximumPrice.getAsDouble());
        product_viewer.setAverage_price(average.getAsDouble());

        return product_viewer;
    }



    //Calculate prizzy price or ideal price and here we choose admin in workers
    @RequestMapping("/products/{workerId}")
    public double getAllProductsByPrice(@PathVariable(value = "workerId") Long workerId) {
        List<Product> products = productRepository.findByWorkerId(workerId);
        Collections.sort(products, new Comparator<Product>() {
            @Override
            public int compare(Product o1, Product o2) {
                if(o1.getPrice()>o2.getPrice())
                {
                    return 1;
                }
                else
                {
                    return -1;
                }
            }
        });
        products.remove(products.get(0));
        products.remove(products.get(1));
        products.remove(products.get(products.size()));
        products.remove(products.get(products.size()-1));

        Product averageProduct=products.get((products.size())/2);
        double average_price=averageProduct.getPrice();

     /*  OptionalDouble prizzyPrice = products
                .stream()
                .mapToDouble(p->p.getPrice())
                .average();*/

       double price_20percentage= average_price*(20/100);

       double prizzyPrice=average_price+price_20percentage;

        return prizzyPrice;
    }

    //Add Product price by worker

    @RequestMapping(value = "/product/{workerId}", method = RequestMethod.POST)
    public Product createProduct(@PathVariable(value = "workerId") Long workerId,
                                  @RequestBody Product product) {
        return workerRepository.findById(workerId).map(worker -> {
            product.setWorker(worker);
            return productRepository.save(product);
        }).orElseThrow(() -> new ResourceNotFoundException("workId " + workerId + " not found"));
    }


}
