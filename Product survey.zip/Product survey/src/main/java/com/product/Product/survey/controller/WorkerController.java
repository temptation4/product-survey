package com.product.Product.survey.controller;

import com.product.Product.survey.exception.ResourceNotFoundException;
import com.product.Product.survey.model.Worker;
import com.product.Product.survey.repository.WorkerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.List;

import static javax.print.attribute.standard.ReferenceUriSchemesSupported.HTTP;

@RestController
public class WorkerController {

    @Autowired
    private WorkerRepository WorkerRepository;

    @RequestMapping("/workers")
    public List<Worker> getAllWorkers() {
        return WorkerRepository.findAll();
    }

    @RequestMapping(value = "/Workers",method = RequestMethod.POST)
    public Worker createWorker( @RequestBody Worker Worker) {
        return WorkerRepository.save(Worker);
    }


}
