package com.product.Product.survey.model;

import javax.persistence.Entity;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.*;

@Entity
@Table(name = "worker")
public class Worker {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String description;


    @OneToMany(cascade = CascadeType.ALL,
            fetch = FetchType.LAZY,
            mappedBy = "worker")
    private Set<Product> comments = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public Set<Product> getComments() {
        return comments;
    }

    public void setComments(Set<Product> comments) {
        this.comments = comments;
    }

    public Worker( String description, Set<Product> comments) {
        this.description = description;
        this.comments = comments;
    }

   public Worker()
    {

    }
}