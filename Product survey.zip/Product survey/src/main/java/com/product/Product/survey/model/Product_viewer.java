package com.product.Product.survey.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Product_viewer {

    @JsonProperty("barcode")
    private String barcode;
    @JsonProperty("product_description")
    private String product_description;
    @JsonProperty("average_price")
    private double average_price;
    @JsonProperty("lowest_price")
    private double lowest_price;
    @JsonProperty("highest_prise")
    private double highest_price;
    @JsonProperty("ideal_price")
    private double ideal_price;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getProduct_description() {
        return product_description;
    }

    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    public double getAverage_price() {
        return average_price;
    }

    public void setAverage_price(double average_price) {
        this.average_price = average_price;
    }

    public double getLowest_price() {
        return lowest_price;
    }

    public void setLowest_price(double lowest_price) {
        this.lowest_price = lowest_price;
    }

    public double getHighest_price() {
        return highest_price;
    }

    public void setHighest_price(double highest_price) {
        this.highest_price = highest_price;
    }

    public double getIdeal_price() {
        return ideal_price;
    }

    public void setIdeal_price(double ideal_price) {
        this.ideal_price = ideal_price;
    }
}
